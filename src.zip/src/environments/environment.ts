

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false, 
    firebaseConfig: {
    apiKey: "AIzaSyCr3WGsi5Xs6abp9FypIShbf7z_-WvY41o",
    authDomain: "break-branch.firebaseapp.com",
    databaseURL: "https://break-branch-default-rtdb.firebaseio.com",
    projectId: "break-branch",
    storageBucket: "break-branch.appspot.com",
    messagingSenderId: "886055831395",
    appId: "1:886055831395:web:8088712b70e0c87632b556",
    measurementId: "G-6FWPBF0HY5"
  }
  };

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
