import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BancodedadosService } from '../services/firebase.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit{
  
  ListCad = [
           { img:'https://cdn.pixabay.com/photo/2017/01/31/13/50/headphones-2024215__340.png'}
   ];

  public formularioGrupo: FormGroup;
  
  constructor(
    private fb: FormBuilder,
    private bancodados: BancodedadosService,
    private navCtrl: NavController
  ) {}

  ngOnInit(): void {
    this.validForm();
  }

  private validForm(){
    this.formularioGrupo = this.fb.group({
      imagem: ['',[Validators.required, Validators.minLength(3)]],
      profissao: ['',[Validators.required, Validators.minLength(3)]],
      nome:['', [Validators.required, Validators.minLength(3)]],
      idade:['', [Validators.required, Validators.minLength(3)]],
      contato:['', [Validators.required, Validators.minLength(3)]],
      cpf:['', [Validators.required, Validators.minLength(3)]],
      email:['', [Validators.required, Validators.minLength(3)]],
      senha:['', [Validators.required, Validators.minLength(3)]]
      
    });
  }

  private salvar(){    
    this.bancodados.cadProduct(this.formularioGrupo.value);
    this.navCtrl.navigateBack('/tabs');
  }
}
