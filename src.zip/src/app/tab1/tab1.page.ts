import { Component, OnInit } from '@angular/core';
import { BancodedadosService } from '../services/firebase.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit { 
 
title= "Instrumentos";

 ListInstrumento = [];
  constructor(
  private bancodados: BancodedadosService,
  ){}

  ngOnInit(): void{
    this.bancodados.getAllProduct().subscribe(results => this.ListInstrumento = results);
  
  }

 excluir(id){
   this.bancodados.delProduct(id);
 }

}
