import { Injectable } from '@angular/core';
import { AngularFirestoreCollection, AngularFirestore } from '@angular/fire/firestore/';

import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BancodedadosService {
 
  cxColecoes: AngularFirestoreCollection;

  constructor(
    // Funcionario responsável por verificar as coleções e atualiza no Firebase
    private af: AngularFirestore) {
    this.cxColecoes = this.af.collection('Produtos');
  }

  //Método de cadastro
  cadProduct(instrumentos) {
    return this.cxColecoes.add(instrumentos);
  }

  //Metodo de consulta todos os dados
  getAllProduct() {
    return this.cxColecoes.snapshotChanges().pipe(
      map(actions => {
        return actions.map(a => {
          const data = a.payload.doc.data();
          const id = a.payload.doc.id;
          return { id, ...data }
        })
      })
    )
  }

  //Metodo consulta um unico produto
  getProduct(id: string) {
    return this.cxColecoes.doc(id).valueChanges();
  }


  //Metodo que apaga um produto
  delProduct(id: string) {
    return this.cxColecoes.doc(id).delete();
  }

  //Metodo que atualiza um produto
  upProduct(id: string , instrumentos) {
    return this.cxColecoes.doc(id).update(instrumentos);
  }
}
